A=[3 1 1; %��һ��
    2 1 2
    1 2 3;]
B=[1 1 -1;
    2 -1 0;
    1 -1 1;]
ans1=2*A+B
ans2=4*A^2-3*B^2
ans3=A*B
ans4=B*A
ans5=ans3-ans4
%%
