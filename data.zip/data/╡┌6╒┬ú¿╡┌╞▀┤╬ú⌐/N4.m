clear
x=input('����')
s=0;
for  j=0:100
    s=s+(x^j)/factorial(j)
end
s
    
