
for i=0:5
    a(i)=input('1');
end
csvwrite(student.csv,a);