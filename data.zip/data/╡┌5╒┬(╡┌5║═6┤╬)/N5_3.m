n=0
a=0;
c=0;
while(n~=-1)
    n=input('������');
    h=n;
    h=h+a;
    a=h;
    c=c+1;
end
h=h+1;
c
h

