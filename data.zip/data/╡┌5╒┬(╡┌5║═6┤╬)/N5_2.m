function y=fenuan(x)
x=input('����');
if(x<0)
    y=x+1;
elseif(x>=0 && x<1)
        y=1;
    else 
            y=x^3;
end
end