r=(0.1:0.1:1)
R=[r,1,1,1,1,1,1,1,1,1]
[x,y,z]=cylinder(R,100)
surf(x,y,z)