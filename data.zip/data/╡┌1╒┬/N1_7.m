a=8.5; b=14.6; c=18.4;
s=(a+b+c)/2;
sns=sqrt(s*(s-a)*(s-b)*(s-c));
sns