x=linspace(-5,5);
y=x.^3+x+1;
plot(x,y)
