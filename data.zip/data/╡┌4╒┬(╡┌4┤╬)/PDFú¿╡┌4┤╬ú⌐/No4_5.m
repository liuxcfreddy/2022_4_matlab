X=[2 3 4 5];
pie(X,explode)
