t=linspace(0,2*pi);
y=3*sin(t);
x=2*cos(t);
plot(x,y,'r-');
grid on;
axis [-6,6-6,6];